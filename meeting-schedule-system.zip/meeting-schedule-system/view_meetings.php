<?php
include("auth.php");
include("db.php");

// Fetch all meetings grouped by meeting_id, date-wise
$query = mysqli_query($conn, "
    SELECT * FROM meeting_faculty 
    ORDER BY meeting_date DESC, start_time ASC
");

// Organize by meeting_id
$meetings = [];
while ($row = mysqli_fetch_assoc($query)) {
    $meetings[$row['meeting_id']]['room'] = $row['room_name'];
    $meetings[$row['meeting_id']]['date'] = $row['meeting_date'];
    $meetings[$row['meeting_id']]['start'] = $row['start_time'];
    $meetings[$row['meeting_id']]['end'] = $row['end_time'];
    $meetings[$row['meeting_id']]['faculty'][] = [
        'name' => $row['faculty_name'],
        'designation' => $row['designation']
    ];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Meetings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f0ff;
            padding: 40px;
            display: flex;
            justify-content: center;
        }
        .container {
            width: 90%;
            max-width: 900px;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 10px #b992f7;
        }
        h2 {
            text-align: center;
            color: #5c3399;
            margin-bottom: 30px;
        }
        .meeting-box {
            border: 1px solid #ccc;
            margin-bottom: 25px;
            border-radius: 10px;
            padding: 20px;
        }
        .meeting-header {
            font-weight: bold;
            color: #4b2d8f;
            margin-bottom: 10px;
        }
        ul {
            padding-left: 20px;
        }
        li {
            margin-bottom: 5px;
        }
        .back-btn {
            display: block;
            margin: 0 auto 20px auto;
            width: 200px;
            text-align: center;
            padding: 10px;
            background-color: #a566ff;
            color: white;
            border-radius: 8px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>📋 Scheduled Meetings</h2>

    <a href="schedule.php" class="back-btn">➕ Schedule New Meeting</a>

    <?php if (empty($meetings)): ?>
        <p style="text-align:center;">No meetings scheduled yet.</p>
    <?php else: ?>
        <?php foreach ($meetings as $id => $meeting): ?>
            <div class="meeting-box">
                <div class="meeting-header">
                    📍 Room: <?= $meeting['room'] ?> |
                    🗓️ <?= date('d-M-Y', strtotime($meeting['date'])) ?> |
                    🕒 <?= date('h:i A', strtotime($meeting['start'])) ?> - <?= date('h:i A', strtotime($meeting['end'])) ?>
                </div>
                <div><strong>👨‍🏫 Faculty Attending:</strong></div>
                <ul>
                    <?php foreach ($meeting['faculty'] as $f): ?>
                        <li><?= $f['name'] ?> (<?= $f['designation'] ?>)</li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>
