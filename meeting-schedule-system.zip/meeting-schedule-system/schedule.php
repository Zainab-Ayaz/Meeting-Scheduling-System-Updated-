<?php
include("auth.php");
include("db.php");

// Fetch faculty
$faculty_query = mysqli_query($conn, "SELECT * FROM faculty");
$faculty_list = [];
while ($row = mysqli_fetch_assoc($faculty_query)) {
    $faculty_list[] = $row;
}

// Fetch rooms
$room_query = mysqli_query($conn, "SELECT * FROM rooms");
$room_list = [];
while ($row = mysqli_fetch_assoc($room_query)) {
    $room_list[] = $row;
}

// Form handling
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $faculty_json = $_POST['faculty_data'];
    $faculty_array = json_decode($faculty_json, true);

    $room = $_POST['room_name'];
    $date = $_POST['date'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];
    $created_by = $_SESSION['email'];
    $meeting_id = time(); // Unique ID for the meeting

    // 1. Room conflict check
    $room_conflict = mysqli_query($conn, "
        SELECT * FROM meeting_faculty 
        WHERE room_name = '$room' 
        AND meeting_date = '$date'
        AND (start_time < '$end' AND end_time > '$start')
    ");

    if (mysqli_num_rows($room_conflict) > 0) {
        $error = "⚠️ The selected room is already booked for that time.";
    } else {
        // 2. Faculty conflict check
        $faculty_conflict = false;
        foreach ($faculty_array as $f) {
            $faculty_name = mysqli_real_escape_string($conn, $f['name']);
            $check = mysqli_query($conn, "
                SELECT * FROM meeting_faculty 
                WHERE faculty_name = '$faculty_name'
                AND meeting_date = '$date'
                AND (start_time < '$end' AND end_time > '$start')
            ");
            if (mysqli_num_rows($check) > 0) {
                $faculty_conflict = $faculty_name;
                break;
            }
        }

        if ($faculty_conflict) {
            $error = "⚠️ $faculty_conflict is already scheduled for another meeting at this time.";
        } else {
            foreach ($faculty_array as $f) {
                $name = mysqli_real_escape_string($conn, $f['name']);
                $designation = mysqli_real_escape_string($conn, $f['designation']);

                mysqli_query($conn, "
                    INSERT INTO meeting_faculty (meeting_id, faculty_name, designation, room_name, meeting_date, start_time, end_time)
                    VALUES ('$meeting_id', '$name', '$designation', '$room', '$date', '$start', '$end')
                ");
            }
            $success = "✅ Meeting scheduled with " . count($faculty_array) . " faculty members.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Schedule Meeting</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f0ff;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding-top: 40px;
        }
        .container {
            background: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 10px #b992f7;
            width: 600px;
        }
        h2 {
            text-align: center;
            color: #5c3399;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }
        select, input, button {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button[type="button"] {
            background-color: #a566ff;
            color: white;
            border: none;
        }
        button[type="submit"] {
            background-color: #5c3399;
            color: white;
            border: none;
            margin-top: 20px;
        }
        table {
            width: 100%;
            margin-top: 15px;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #bbb;
            padding: 8px;
            text-align: center;
        }
        .success { color: green; text-align: center; }
        .error { color: red; text-align: center; }
    </style>
</head>
<body>

<div class="container">
    <h2>📅 Schedule a Meeting</h2>

    <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="POST" action="">

        <!-- Faculty Dropdown -->
        <label>Select Faculty:</label>
        <select id="facultySelect">
            <option disabled selected>Select a faculty member</option>
            <?php foreach ($faculty_list as $f) {
                echo "<option value='{$f['name']}' data-designation='{$f['designation']}'>{$f['name']}</option>";
            } ?>
        </select>

        <!-- Auto-filled Designation -->
        <input type="text" id="designation" placeholder="Designation" readonly>

        <!-- Add Faculty Button -->
        <button type="button" onclick="addFaculty()">➕ Add Faculty</button>

        <!-- Faculty Table -->
        <table id="facultyTable">
            <tr>
                <th>Faculty Name</th>
                <th>Designation</th>
                <th>Action</th>
            </tr>
        </table>

        <!-- Hidden input for PHP -->
        <input type="hidden" name="faculty_data" id="facultyData">

        <!-- Room Dropdown -->
        <label>Select Room:</label>
        <select name="room_name" required>
            <option disabled selected>Select a Room</option>
            <?php foreach ($room_list as $room) {
                echo "<option value='{$room['room_name']}'>{$room['room_name']}</option>";
            } ?>
        </select>

        <!-- Date and Time Inputs -->
        <label>Date:</label>
        <input type="date" name="date" required>

        <label>Start Time:</label>
        <input type="time" name="start_time" required>

        <label>End Time:</label>
        <input type="time" name="end_time" required>

        <button type="submit" name="submit">✅ Schedule Meeting</button>
    </form>
</div>

<!-- JavaScript for dynamic faculty list -->
<script>
    let facultyList = [];

    function addFaculty() {
        const select = document.getElementById('facultySelect');
        const designationInput = document.getElementById('designation');
        const hiddenInput = document.getElementById('facultyData');

        const selectedOption = select.options[select.selectedIndex];
        const name = selectedOption.value;
        const designation = selectedOption.getAttribute('data-designation');

        if (!name || facultyList.some(f => f.name === name)) {
            alert('Faculty already added or not selected.');
            return;
        }

        facultyList.push({ name, designation });
        updateFacultyTable();
        hiddenInput.value = JSON.stringify(facultyList);
    }

    function updateFacultyTable() {
        const table = document.getElementById('facultyTable');
        table.innerHTML = `
            <tr>
                <th>Faculty Name</th>
                <th>Designation</th>
                <th>Action</th>
            </tr>
        `;
        facultyList.forEach((f, index) => {
            table.innerHTML += `
                <tr>
                    <td>${f.name}</td>
                    <td>${f.designation}</td>
                    <td><button type="button" onclick="removeFaculty(${index})">❌ Remove</button></td>
                </tr>
            `;
        });
    }

    function removeFaculty(index) {
        facultyList.splice(index, 1);
        updateFacultyTable();
        document.getElementById('facultyData').value = JSON.stringify(facultyList);
    }

    document.getElementById('facultySelect').addEventListener('change', function () {
        const selected = this.options[this.selectedIndex];
        document.getElementById('designation').value = selected.getAttribute('data-designation');
    });
</script>

</body>
</html>
